var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["0955dac5-7344-44e3-b11a-06fec17d8290"],"propsByKey":{"0955dac5-7344-44e3-b11a-06fec17d8290":{"name":"ball","sourceUrl":null,"frameSize":{"x":39,"y":38},"frameCount":1,"looping":true,"frameDelay":12,"version":"rLt73xRsPnLAVG5n1oDr3JZVPbMFF8db","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":39,"y":38},"rootRelativePath":"assets/0955dac5-7344-44e3-b11a-06fec17d8290.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var score = 0;
var lives = 3;
var gameState = "serve";

var ball = createSprite(200, 240, 15, 15);
ball.setAnimation("ball");
ball.scale = 0.6;

var paddle = createSprite(190, 340, 100, 15);
paddle.shapeColor = "blue";
createEdgeSprites();
var bricks = createGroup();

function brickRow(y,color) {
 for (var i = 0; i < 6; i++) {
 var brick = createSprite(65+54*i,y,50, 15);
 brick.shapeColor = color;
 bricks.add(brick);

}
}
brickRow(65,"aqua");
brickRow(65+29,"yellow");
brickRow(65+29+29,"purple");
brickRow(65+29+29+29,"violet");

function draw() {
  background("black");
  textSize(20);
  stroke("white");
  text("Score:"+score,20,25);
  stroke("white");
  text("Lives:"+lives,315,25);
  stroke("white");
  if (gameState == "serve") {
    text("Click to start the game", 100, 250);
    ball.velocityX = 0;
    ball.velocityY = 0;
    ball.x = 200;
    ball.y = 200;
  } else if (gameState == "end") {
    ball.destroy();
  } else   {
    gamePlay();
  }
  
  drawSprites();
}

function brickHit(ball, brick) {
  brick.destroy();
  score=score+5;
  playSound("https://audio.code.org/goal1.mp3", false);
}

function mousePressed() {
  if (gameState == "serve"){
    gameState = "play";
  
 ball.velocityX = 4;
    ball.velocityY = 4;
}
}

function lifeOver (){
  lives=lives-1;
  if (lives>=1) {
    ball.visible = true;
    gameState="serve";
  } else {
    gameState="end";
  }
  
}
//if the game is on and has started
function gamePlay() {
  paddle.x = World.mouseX;
  if (paddle.x<60) {
    paddle.x = 60;
  }
  if (paddle.x>340) {
    paddle.x = 340;
  }
  ball.bounceOff(topEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(paddle);
  ball.bounceOff(bricks,brickHit);
  if (!bricks[0]){
    ball.velocityX = 0;
    ball.velocityY = 0;
    text("Well done! You win the game!",80, 200);
  }
  if (ball.isTouching(bottomEdge)) {
    playSound("https://audio.code.org/losepoint2.mp3", false);
    ball.visible = false;
  lifeOver();
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
